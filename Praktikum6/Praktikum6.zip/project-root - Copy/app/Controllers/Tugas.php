<?php

namespace App\Controllers;
use App\Models\TugasMahasiswaModel;

class Tugas extends BaseController
{    
    public function index()
    {   
        $data =[
            'title' => 'BERANDA'
        ];
        echo view('layout/header', $data);
        $mahasiswa = new TugasMahasiswaModel();
        echo view('Tugas/beranda', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim()
        ]);
        echo view('layout/footer');
    }
    public function profil()
    {   
        $data =[
            'title' => 'BIODATA'
        ];
        echo view('layout/header', $data);
        $mahasiswa = new TugasMahasiswaModel();
        echo view('Tugas/profil', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
            "prodi" => $mahasiswa->getProdi(),
            "hobi" => $mahasiswa->getHobi(),
            "skill" => $mahasiswa->getSkill(),
            "info" => $mahasiswa->getInfo()
        ]);
        echo view('layout/footer');
    }
} 
