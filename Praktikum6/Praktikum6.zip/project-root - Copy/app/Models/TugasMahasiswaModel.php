<?php

namespace App\Models;

use CodeIgniter\Model;

class TugasMahasiswaModel extends Model
{
    protected $nama ="Maulana Khisyam";
    protected $nim ="2110817110009";
    protected $prodi ="S1-Teknologi Informasi";
    protected $hobi ="Bulutangkis";
    protected $skill ="Bismilah Koding";
    protected $info = "Follow ig @hisyamaulana_16";
    
    public function getNama(){
        return $this->nama;
    }
    public function getNim(){
        return $this->nim;
    }
    public function getProdi(){
        return $this->prodi;
    }
    public function getHobi(){
        return $this->hobi;
    }
    public function getSkill(){
        return $this->skill;
    }
    public function getInfo(){
        return $this->info;
    }
}
