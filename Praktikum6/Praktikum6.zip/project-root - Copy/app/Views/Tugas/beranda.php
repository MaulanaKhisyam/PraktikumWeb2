<div class="container">
    <div class="row">
        <div class="col">
            <center>
                <img style='width:200px; height: 250px;'src="<?= base_url('gambar/foto.JPG') ?>" alt="gambar saya"><br><br>
                <?php echo($nama)?> <br>
                <?= $nim?> <br><br>
                <button><a href="/Tugas/profil">Profil</a></button>
            </center>
        </div>
    </div>
</div>
