<div class="container">
    <div class="row">
        <div class="col">
            <div class="card">
            <center>
                <h2><?= $nama?></h2>
                <table border="2px">
                    <tr>
                        <td colspan="2">
                            <center>
                                <img style='width:200px; height: 250px;'src="<?= base_url('gambar/foto.JPG') ?>" alt="gambar saya">
                            </center>
                        </td>
                    </tr>
                    <tr>
                        <td>NIM </td> 
                        <td>
                            :<?= $nim?>
                        </td>
                    </tr>
                    <tr>
                        <td>Asal Prodi</td>
                        <td>
                            :<?= $prodi?>
                        </td>
                    </tr>
                    <tr>
                        <td>Hobi</td>
                        <td>
                            :<?= $hobi?> 
                        </td>
                    </tr>
                    <tr>
                        <td>Skill</td>
                        <td>
                            :<?= $skill?>  
                        </td>
                    </tr>
                    <tr>
                        <td>Informasi</td>
                        <td>
                            :<?= $info?>  
                        </td>
                    </tr>
                </table>
            </center> 
            </div>
        </div>
    </div>
</div>   