<?php

namespace App\Database\Seeds;

use App\Models\CrudModel;
use CodeIgniter\Database\Seeder;

class CrudSeeder extends Seeder
{
    public function run()
    {
        $model = new CrudModel();
        $model->insert(
            [
                "nama" => "Maulana Khisyam",
                "nim" => "2110817110009",
                "alamat" => "Barito Kuala"
            ]
            );
    }
}
